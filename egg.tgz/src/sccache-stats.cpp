// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("sccache stats\n", stdout);
  return lionss_run_workload("sccache-stats");
}
