// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("macrobench\n", stdout);
  return lionss_run_workload("macrobench");
}
