// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("numa bench\n", stdout);
  return lionss_run_workload("numa-bench");
}
