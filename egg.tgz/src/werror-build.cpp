// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("werror build"); }
int main(){
  announce();
  return lionss_run_workload("werror-build");
}
